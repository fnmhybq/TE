from django.db import models

# Create your models here.

class Mag(models.Model):
    issue = models.CharField(max_length=64,blank=False)
    title = models.CharField(max_length=256,blank=False)
    url_pdf = models.CharField(max_length=128,blank=True)
    url_epub = models.CharField(max_length=128,blank=True)
    url_mobi = models.CharField(max_length=128,blank=True)
    size_pdf = models.CharField(max_length=32,blank=True)
    size_epub = models.CharField(max_length=32,blank=True)
    size_mobi = models.CharField(max_length=32,blank=True)
    code_pdf = models.CharField(max_length=32, blank=True)
    code_epub = models.CharField(max_length=32, blank=True)
    code_mobi = models.CharField(max_length=32, blank=True)
    ps_pdf = models.CharField(max_length=128,blank=True)
    ps_epub = models.CharField(max_length=128, blank=True)
    ps_mobi = models.CharField(max_length=128, blank=True)

    def __str__(self):
        return self.issue