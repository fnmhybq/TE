from django.contrib import admin

# Register your models here.

from te.models import Mag

admin.site.register(Mag)