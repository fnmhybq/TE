from django.shortcuts import render

# Create your views here.
from . import models


def index(request):
    data = models.Mag.objects.all()
    return render(request,'index.html',{'data':data})
