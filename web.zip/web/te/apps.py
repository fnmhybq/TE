from django.apps import AppConfig


class TeConfig(AppConfig):
    name = 'te'
